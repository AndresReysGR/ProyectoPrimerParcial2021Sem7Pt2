//
//  ViewController.swift
//  ProyectoPrimerParcial
//
//  Created by Alumno on 9/15/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImgAnimacionConejo: UIImageView!
    @IBOutlet weak var ImgAnimacionRaton: UIImageView!
    @IBOutlet weak var ImgAnimacionHamster: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ImgAnimacionConejo.animationImages = [
            UIImage(named: "Serpiente_1")!,
            UIImage(named: "Serpiente_2")!,
            UIImage(named: "Serpiente_3")!,
            UIImage(named: "Serpiente_4")!,
            UIImage(named: "Serpiente_5")!
        ]
        ImgAnimacionConejo.animationDuration = 2.0
        ImgAnimacionConejo.startAnimating()
        
        ImgAnimacionRaton.animationImages = [
            UIImage(named: "Rata_1")!,
            UIImage(named: "Rata_2")!,
            UIImage(named: "Rata_3")!,
            UIImage(named: "Rata_4")!,
            UIImage(named: "Rata_5")!
        ]
        ImgAnimacionRaton.animationDuration = 2.0
        ImgAnimacionRaton.startAnimating()
        
        ImgAnimacionHamster.animationImages = [
            UIImage(named: "Hamster_1")!,
            UIImage(named: "Hamster_2")!,
            UIImage(named: "Hamster_3")!,
            UIImage(named: "Hamster_4")!,
            UIImage(named: "Hamster_5")!
        ]
        ImgAnimacionHamster.animationDuration = 2.0
        ImgAnimacionHamster.startAnimating()
    }
    


}

